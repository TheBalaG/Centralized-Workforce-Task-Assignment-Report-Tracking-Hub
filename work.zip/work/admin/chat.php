<!DOCTYPE html>
<html lang="en">

<head>
    <?php  
    session_start();
    if(!$_SESSION['admin_email'])
    {
         header('Location: ../index.php');
        exit;
    }
    ?>

    <?php
   
        $pageTitle = "Dashboard"; // Set the custom title for this page
        $cssFileName = "../css/admin.css";
        include "../head.php"; // Include the common head section
		 include "../php/config.php";

        $gender = $_SESSION['admin_gender'];
        $name = $_SESSION['admin_name'];
		$user_id= $_SESSION['admin_name'];
		
	

if (isset($_POST['message']) && !empty($_POST['message'])) {
    $message = $_POST['message'];

    $sql = "INSERT INTO messages (user_id, message, timestamp) VALUES ('$user_id', '$message', NOW())";
    if ($conn->query($sql) === TRUE) {
        echo "success";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    exit; // Exit to prevent further execution
}


// Fetch messages
$sql = "SELECT * FROM messages ORDER BY timestamp DESC";
$result = $conn->query($sql);
$messages = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }
}

$conn->close();
?> 
    <link rel="stylesheet" href="../css/sidebar.css">
    <link rel="stylesheet" href="../css/topbar.css">

  <style>
        #chat-container {
            height: 300px;
            overflow-y: auto;
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 10px;
			width: 500px;
        }
    </style>


</head>


<body>
  <div class="container">
        <!-- **** Navigation Bar **** -->
        <?php include 'adminSidebar.php' ?>
   
        <!-- Main Content-->
        <div class="main">

            <!--- ***** Topbar ****** -->
            <?php include 'adminTopbar.php' ?>

    <div id="chat-container">
        <?php foreach ($messages as $msg): ?>
            <p><strong><?php echo $msg['user_id']; ?>:</strong> <?php echo $msg['message']; ?></p>
        <?php endforeach; ?>
    </div>
	
    <form id="message-form">
        <input type="text" id="message-input" name="message" placeholder="Type your message">
        <button type="submit">Send</button>
    </form>

    <script>
        document.getElementById('message-form').addEventListener('submit', function(e) {
            e.preventDefault();
            var messageInput = document.getElementById('message-input').value;
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        // Message sent successfully, update chat window
                        document.getElementById('message-input').value = '';
                        var chatContainer = document.getElementById('chat-container');
                        var p = document.createElement('p');
                        p.innerHTML = '<strong><?php echo $user_id; ?>:</strong> ' + messageInput;
                        chatContainer.appendChild(p);
                        chatContainer.scrollTop = chatContainer.scrollHeight; // Scroll to bottom
                    } else {
                        // Handle error
                        console.error('Error:', xhr.responseText);
                    }
                }
            };
            xhr.open('POST', 'chat.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.send('message=' + messageInput);
        });
    </script>
</body>
</html>
