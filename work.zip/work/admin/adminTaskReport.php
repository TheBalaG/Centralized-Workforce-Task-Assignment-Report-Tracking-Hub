<!DOCTYPE html>
<html lang="en">

<head>
    
    <?php
    
        $pageTitle = "Task Report"; // Set the custom title for this page
        $cssFileName = "../css/admin.css";
        include "../head.php"; // Include the common head section
    ?> 
    <link rel="stylesheet" href="../css/sidebar.css">
    <link rel="stylesheet" href="../css/topbar.css">

</head>
<body>
    
<?php 
        session_start();

        include '../php/config.php';

        $gender = $_SESSION['admin_gender'];
        $name = $_SESSION['admin_name'];

        $currentDateTime = new DateTime();
        $currentDateTime->setTime(0, 0, 0);
        $currentDateTime->modify('first day of this month');
        $firstDayOfMonth = $currentDateTime->format('Y-m-d H:i:s');
        $firstDay = $currentDateTime->format('d-m-Y');
        $currentDateTime->modify('last day of this month');
        $lastDayOfMonth = $currentDateTime->format('Y-m-d H:i:s');
        $lastDay = $currentDateTime->format('d-m-Y');

        $sql_inprogress_task = "SELECT E.emp_name, T.task_title, TS.updated_info, TS.updated_date, T.endDate, T.task, TS.task_status, T.task_id,T.startDate,T.task_desc
        FROM DEPARTMENT D, EMPLOYEE E, TASK T, TASK_STATUS TS
        WHERE D.dept_id = E.dept_id AND E.emp_id = TS.emp_id AND T.task_id = TS.task_id AND TS.task_status = 'In Progress' AND T.startDate >= '$firstDayOfMonth' AND T.endDate <= '$lastDayOfMonth'";
        
        $result_inprogress_task = $conn->query($sql_inprogress_task);

        ?>
    <?php

            if (isset($_POST['start_date']) && isset($_POST['end_date'])) 
            
            {
                $firstDayOfMonth = $_POST['start_date'];
                $lastDayOfMonth = $_POST['end_date'];
                // echo  $firstDayOfMonth;
                // echo $lastDayOfMonth;
                
                
               
    // If start and end dates are the same, include tasks with the same start and end dates
    $dateCondition = ($firstDayOfMonth == $lastDayOfMonth)
        ? "AND DATE(T.startDate) = '$firstDayOfMonth'"
        : "AND DATE(T.startDate) >= '$firstDayOfMonth' AND DATE(T.endDate) <= '$lastDayOfMonth' ORDER BY T.endDate DESC";

            $sql_completed_task = "SELECT E.emp_name, T.task_title, TS.updated_info, TS.updated_date, T.endDate, T.task, TS.task_status, T.task_id, T.startDate, T.task_desc
            FROM DEPARTMENT D, EMPLOYEE E, TASK T, TASK_STATUS TS
            WHERE D.dept_id = E.dept_id
            AND E.emp_id = TS.emp_id
            AND T.task_id = TS.task_id
            AND TS.task_status = 'Completed'".
            $dateCondition;


                
                ///
                
                // $sql_completed_task = "SELECT E.emp_name, T.task_title, TS.updated_info, TS.updated_date, T.endDate, T.task, TS.task_status, T.task_id, T.startDate, T.task_desc
                //     FROM DEPARTMENT D, EMPLOYEE E, TASK T, TASK_STATUS TS
                //     WHERE D.dept_id = E.dept_id AND E.emp_id = TS.emp_id AND T.task_id = TS.task_id AND TS.task_status = 'Completed' AND T.startDate >= '$firstDayOfMonth' AND T.endDate <= '$lastDayOfMonth'";
            } else {
                $currentDateTime = new DateTime();
                $currentDateTime->setTime(0, 0, 0);
                $currentDateTime->modify('first day of this month');
                $firstDayOfMonth = $currentDateTime->format('Y-m-d H:i:s');
                $firstDay = $currentDateTime->format('d-m-Y');
                $currentDateTime->modify('last day of this month');
                $lastDayOfMonth = $currentDateTime->format('Y-m-d H:i:s');
                $lastDay = $currentDateTime->format('d-m-Y');
            
                $sql_completed_task = "SELECT E.emp_name, T.task_title, TS.updated_info, TS.updated_date, T.endDate, T.task, TS.task_status, T.task_id, T.startDate, T.task_desc
                    FROM DEPARTMENT D, EMPLOYEE E, TASK T, TASK_STATUS TS
                    WHERE D.dept_id = E.dept_id AND E.emp_id = TS.emp_id AND T.task_id = TS.task_id AND TS.task_status = 'Completed' AND T.startDate >= '$firstDayOfMonth' AND T.endDate <= '$lastDayOfMonth' ORDER BY T.endDate DESC";
            }
            
            // Execute the SQL query and fetch results
            $result_completed_task = $conn->query($sql_completed_task);
            
             if ($result_completed_task) {
                if ($result_completed_task->num_rows > 0) {
                    echo "Got results";
                } else {
                    echo "No records found";
                }
            } else {
                echo "Error executing the query: " . $conn->error;
            }
            
            $conn->close();
    
    ?>

    <div class="container">
        <!-- **** Navigation Bar **** -->
        <?php include 'adminSidebar.php' ?>
   
        <!-- Main Content-->
        <div class="main">

            <!--- ***** Topbar ****** -->
            <?php include 'adminTopbar.php' ?>

            <!--- ***** Task Status ****** -->
            <section id="taskReport">
                    
                
                    
                <!--- ***** Box ****** -->
                <div class="box">
                    <div class="title">
                        <p>Task Report:</p>
                    </div>

                    <div class="innerBox">
                        <div class="title">
                            <p>In Progress Tasks</p>
                        </div>
                        <!--- ***** In Progress Tasks ****** -->
                        <table>
                            <tr>
                                <th>S.No</th>
                                <th>ID</th>
                                <th>Assigned To</th>
                                <th>Client Name</th>
                                <th>Site Location</th>
                                <th>Start Date</th>
                                <th>Task Type</th>
                                <th>Task Status</th>
                                <th>Updated Date</th>
                                <th>View Files</th>
                            </tr>
                            <?php
                                if ($result_inprogress_task->num_rows > 0) {
                                    $serialNo = 1; // Initialize the serial number
                                    while ($row = $result_inprogress_task->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td>" . $serialNo . "</td>";
                                        echo "<td>" . $row["task_id"] . "</td>";
                                        echo "<td>" . $row["emp_name"] . "</td>";
                                        echo "<td>" . $row["task_title"] . "</td>";
                                        echo "<td>" . $row["task_desc"] . "</td>";
                                        echo "<td>" . $row["startDate"] . "</td>";
                                        echo "<td>" . $row["task"] . "</td>";
                                        echo "<td>" . $row["task_status"] . "</td>";
                                        echo "<td>" . $row["updated_date"] . "</td>";
                                        echo "<td> <a href='viewFiles.php?path=../uploads/".$row["task_id"]."'>View Files</a> </td>";
                                        
                                        echo "</tr>";
                                        $serialNo++; 
                                    }
                                } else {
                                    echo "<tr><td colspan='8'>No records found</td></tr>";
                                }
                            ?>
                        </table>
                    </div>

                    
                    <div class="innerBox">
                        <!--- ***** Completed Tasks ****** -->
                        <div class="title">
                            <?php 
                            if(isset($_POST['start_date'])) {
                                echo '<p>Completed Tasks From  ' . $_POST['start_date'] . "  to  " . $_POST['end_date'] . "</p>";
                            } else {
                                echo '<p>Completed Tasks From  ' . $firstDay . "  to  " . $lastDay . "</p>";
                            }
                            
            
                            ?>
                        </div>

                        
                        <form method="post" action="adminTaskReport.php">
                        <label for="start_date">Start Date:</label>
                        <input type="date" id="start_date" name="start_date" required>

                        <label for="end_date">End Date:</label>
                        <input type="date" id="end_date" name="end_date" required>

                        <button type="submit">Generate Report</button>
                        </form>

                        
                        
                        <table>
                            <tr>
                                <th>S.No</th>
                                <th>ID</th>
                                <th>Assigned To</th>
                                <th>Client Name</th>
                                <th>Location</th>
                                <th>Remark</th>
                                <th>Task Type</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>View Files</th>
                            </tr>
                            <?php
                                if ($result_completed_task->num_rows > 0) {
                                    $serialNo = 1; // Initialize the serial number
                                    while ($row = $result_completed_task->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td>" . $serialNo . "</td>";
                                        echo "<td>" . $row["task_id"] . "</td>";
                                        echo "<td>" . $row["emp_name"] . "</td>";
                                        echo "<td>" . $row["task_title"] . "</td>";
                                        echo "<td>" . $row["task_desc"] . "</td>";
                                        echo "<td>" . $row["updated_info"] . "</td>";
                                        echo "<td>" . $row["task"] . "</td>";
                                        echo "<td>" . $row["startDate"] . "</td>";
                                        echo "<td>" . $row["endDate"] . "</td>";
                                        echo "<td> <a href='viewFiles.php?path=../uploads/".$row["task_id"]."'>View Files</a> </td>";
                                        echo "</tr>";
                                        $serialNo++; 
                                    }
                                } else {
                                    echo "<tr><td colspan='8'>No records found</td></tr>";
                                }
                            ?>
                        </table>
                    </div>
                </div>
                
            </section>            

        </div>

    </div>

    <script src="../js/adminDashboard.js"></script>    
    <script src="../js/validation.js"></script>    

</body>

</html>