<!DOCTYPE html>
<html lang="en">

<head>
    <?php  
    session_start();
    if(!$_SESSION['admin_email'])
    {
         header('Location: ../index.php');
        exit;
    }
    ?>

    <?php
   
        $pageTitle = "Dashboard"; // Set the custom title for this page
        $cssFileName = "../css/admin.css";
        include "../head.php"; // Include the common head section
    ?> 
    <link rel="stylesheet" href="../css/sidebar.css">
    <link rel="stylesheet" href="../css/topbar.css">

</head>


<body>

    <?php 
    
        session_start();

        include "../php/config.php";

        $gender = $_SESSION['admin_gender'];
        $name = $_SESSION['admin_name'];

        $dept = "SELECT COUNT(*) as total_dept FROM DEPARTMENT";
        $dept_result = $conn->query($dept);

        if ($dept_result->num_rows >= 0) {
            $dept_row = $dept_result->fetch_assoc();
            $total_dept = $dept_row["total_dept"];
        } 

        $emp = "SELECT COUNT(*) as total_emp FROM EMPLOYEE";
        $emp_result = $conn->query($emp);
        
        if ($emp_result->num_rows >= 0) {
            $emp_row = $emp_result->fetch_assoc();
            $total_emp = $emp_row["total_emp"];
        } 

        $task = "SELECT COUNT(*) as total_task FROM TASK";
        $task_result = $conn->query($task);

        if ($task_result->num_rows >= 0) {
            $task_row = $task_result->fetch_assoc();
            $total_task = $task_row["total_task"];
        } 

        $completedTask = "SELECT COUNT(*) as total_completed_task FROM TASK_STATUS WHERE task_status = 'Completed'";
        $completedTask_result = $conn->query($completedTask);

        if ($completedTask_result->num_rows >= 0) {
            $completedTask_row = $completedTask_result->fetch_assoc();
            $total_completed_task = $completedTask_row["total_completed_task"];
        } 

        $inprogressTask = "SELECT COUNT(*) as total_inprogress_task FROM TASK_STATUS WHERE task_status = 'In Progress'";
        $inprogressTask_result = $conn->query($inprogressTask);

        if ($inprogressTask_result->num_rows >= 0) {
            $inprogressTask_row = $inprogressTask_result->fetch_assoc();
            $total_inprogress_task = $inprogressTask_row["total_inprogress_task"];
        } 

    ?>
    <div class="container">
        <!-- **** Navigation Bar **** -->
        <?php include 'adminSidebar.php' ?>
   
        <!-- Main Content-->
        <div class="main">

            <!--- ***** Topbar ****** -->
            <?php include 'adminTopbar.php' ?>

            <!--- ***** Dashboard ****** -->
            <section id="taskReport">
             
			 <div class="box">
                    <div class="title">
                        <p>File Explorer</p>
                    </div>
			 
                <!-- ***** Cards ***** -->
                <?php
// Function to list files and subdirectories in a directory
function listDirectory($directory) {
    // Check if the directory exists
    if (is_dir($directory)) {
        // Open directory
        if ($dh = opendir($directory)) {
            // Display header
		 echo '<div class="Box">
		 <div class="innerBox">';
					
            // Loop through each file in the directory
            while (($item = readdir($dh)) !== false) {
                // Exclude directories and current/parent directory entries
                if ($item != '.' && $item != '..') {
                    // Determine if the item is a file or directory
                    $itemPath = $directory .'/'. $item;
                    if (is_dir($itemPath)) {
                        // Display directory link
                        echo "<p><strong>Task ID:</strong> <a href='?path=$itemPath'>$item</a></p>";
                    } else {
                        // Display download link for files
                        echo "<p><strong>File:</strong> <a href='$itemPath' download>$item</a></p>";
						echo "</div>
						</div>";
                    }
                }
            }

            // Close directory handle
            closedir($dh);
			
        }
    } else {
        echo "Directory does not exist.";
    }
}

// Get the path from the URL query parameter
$directoryPath = isset($_GET['path']) ? $_GET['path'] : '../uploads/';

// Display the contents of the specified directory
listDirectory($directoryPath);
?>



            </section>            

        </div>

    </div>
    <script src="../js/adminDashboard.js"></script>
    
</body>



</html>