<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
    session_start();
    
    
    include '../php/config.php';

date_default_timezone_set('Asia/Kolkata');


    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        // ------- Admin Login --------

        if (isset($_POST['adminLogin'])) {

            $admin_email  = $_POST['email'];
            $adminPassword   = $_POST['pass'];

            if ( isset($admin_email, $adminPassword) ) {
                // Create connection
                if ($stmt = $conn->prepare(" SELECT admin_id, admin_name, admin_gender, admin_pass FROM ADMIN_MANAGER WHERE admin_email = ?")) {
                    
                    // Bind parameters (s = string, i = int, b = blob, etc), in our case the username is a string so we use "s"
                    $stmt->bind_param('s', $admin_email);
                    $stmt->execute();
                    // Store the result so we can check if the account exists in the database.
                    $stmt->store_result();
                    if ($stmt->num_rows > 0) {
                                                
	                    $stmt->bind_result($admin_id, $admin_name, $admin_gender ,$admin_pass);
                        $stmt->fetch();
                        // Account exists, now we verify the password.
                        if (password_verify($adminPassword, $admin_pass)) {
                            // Verification success! User has logged-in!
                            // Create sessions, so we know the user is logged in, they basically act like cookies but remember the data on the server.
                            session_regenerate_id();
                            $_SESSION['admin_loggedin'] = TRUE;
                            $_SESSION['admin_email'] = $admin_email;
                            $_SESSION['admin_id'] = $admin_id;
                            $_SESSION['admin_name'] = $admin_name;
                            $_SESSION['admin_gender'] = $admin_gender;
                            echo "<script>alert('You\'ve Successfully Logged In!');
                                window.location.href = '../admin/adminDashboard.php'</script>";  //redirect to admin dashboard 
                        } else {
                            // Incorrect password
                            echo '<script>alert("Incorrect Password!")
                                window.location.href = "../adminLogin.php";</script>';
                        }
                    } else {
                        // Incorrect password
                        echo '<script>alert("Account does not exist!");
                            window.location.href = "../adminLogin.php";</script>';
                    }
                
                    $stmt->close();
                }
             }
            else {
                echo "<script>alert('Please fill out the details')</script>";
            }           
        } 

        // ------- Employee Login --------

        if (isset($_POST['employeeLogin'])) {

            $employee_email  = $_POST['email'];
            $employeePassword   = $_POST['pass'];

            if ( isset($employee_email, $employeePassword) ) {
                // Create connection
                if ($stmt = $conn->prepare(" SELECT emp_id, emp_pass FROM EMPLOYEE WHERE emp_email = ?")) {
                    // Bind parameters (s = string, i = int, b = blob, etc), in our case the username is a string so we use "s"
                    $stmt->bind_param('s', $employee_email);
                    $stmt->execute();
                    // Store the result so we can check if the account exists in the database.
                    $stmt->store_result();
                    if ($stmt->num_rows > 0) {
                                                
	                    $stmt->bind_result($employee_id, $employee_pass);
                        $stmt->fetch();
                        // Account exists, now we verify the password.
                        if (password_verify($employeePassword, $employee_pass)) {
                            // Verification success! User has logged-in!
                            // Create sessions, so we know the user is logged in, they basically act like cookies but remember the data on the server.
                            session_regenerate_id();
                            $_SESSION['employee_loggedin'] = TRUE;
                            $_SESSION['employee_email'] = $employee_email;
                            $_SESSION['employee_id'] = $employee_id;
                            echo "<script>alert('You\'ve Successfully Logged In!');
                                window.location.href = '../employee/employeeDashboard.php';</script>";  //redirect to employee dashboard 
                        } else {
                            // Incorrect password
                            echo '<script>alert("Incorrect Password!")
                                window.location.href = "../employeeLogin.php";</script>';
                        }
                    } else {
                        // Incorrect password
                        echo '<script>alert("Account does not exist!");
                            window.location.href = "../employeeLogin.php";</script>';
                    }
                
                    $stmt->close();
                }
             }
            else {
                echo "<script>alert('Please fill out the details')</script>";
            }
        }

        // ------- Add Department --------

        if (isset($_POST['addDepartment'])) {

            $department_name = $_POST['deptm_name'];
            $admin_name = $_POST['admin_name'];

            if ( isset($department_name, $admin_name) ) {
				
			
                $sql = "SELECT dept_id FROM DEPARTMENT WHERE dept_name = ?";
				
				$stmt = $conn->prepare($sql);
				$stmt->bind_param("s", $department_name); // Bind the department name parameter
				$stmt->execute();
				$res = $stmt->get_result();
						
                if ($res->num_rows > 0) 
				{	echo $res->num_rows;
                    echo "<script>alert('Department already exists!');
                        window.location.href = '/work/admin/addDepartment.php';</script>";
                }
                else {
                    // Retrieve the admin id
                    $admin = "SELECT admin_id FROM ADMIN_MANAGER WHERE admin_name = '$admin_name'";
                    $admin_res = $conn->query($admin);

                    if ($admin_res->num_rows > 0) {
                        $row = $admin_res->fetch_assoc();
                        $admin_id = $row["admin_id"];

                        $ins = "INSERT INTO DEPARTMENT (dept_name, admin_id) VALUES ('$department_name', '$admin_id')";
                        if ($conn->query($ins) === TRUE) {
                            echo "<script>alert('Department Added Successfully');
                            window.location.href='../admin/adminDepartment.php'</script>";
                        } 
                        else {
                            echo "<script>alert('Error While Inserting.');
                            window.location.href='../admin/addDepartment.php'</script>";
                        }
                    } 
                                                  
                }
            }
            else {
                echo "<script>alert('Fill out all details');
                window.location.href='../admin/addDepartment.php'</script>";
            } 
        }

        // ------- Edit Department --------

        if (isset($_POST['editDepartment'])) {

            $new_dept_name = $_POST['new_dept_name'];
            $old_dept_name = $_POST['old_dept_name'];

            if ( isset($new_dept_name, $old_dept_name) ) {

                $dept = "SELECT dept_id FROM DEPARTMENT WHERE dept_name = '$old_dept_name'";
                $dept_res = $conn->query($dept);

                if ($dept_res->num_rows > 0) {
                    $row = $dept_res->fetch_assoc();
                    $dept_id = $row["dept_id"];

                    $sql_update = "UPDATE DEPARTMENT SET dept_name = '$new_dept_name' WHERE dept_id = $dept_id";
                    $update_res = $conn->query($sql_update);

                    if($update_res) {
                        echo "<script>alert('Department Updated Successfully');
                        window.location.href='../admin/adminDepartment.php'</script>";
                    } 
                    else {
                        echo "<script>alert('Department Name must be unique.');
                        window.location.href='../admin/adminDepartment.php'</script>";
                    }
                    
                }
            }
            else {
                echo "<script>alert('Fill out all details');
                window.location.href='../admin/adminDepartment.php'</script>";
            } 
        }

        // ------- Add Employee --------
        if (isset($_POST['addEmployee'])) {

            $employee_name = $_POST['emp_name'];
            $employee_email  = $_POST['emp_email'];
            $employee_phone = $_POST['emp_phone'];
            $employee_gender = $_POST['emp_gender'];
            $employeePassword = $_POST['emp_pass'];
            $dept_name = $_POST['dept_name'];

            if ( isset($employee_name, $employee_email, $employee_phone, $employee_gender, $employeePassword, $dept_name) ) {

                $sql = "SELECT emp_id FROM EMPLOYEE WHERE emp_email = ? AND emp_phone = ?";
				$stmt = $conn->prepare($sql);
				$stmt->bind_param("ss", $employee_email, $employee_phone); // Bind the parameters
				$stmt->execute();
				$res = $stmt->get_result();
                if ($res->num_rows > 0) {
                    echo "<script>alert('Account already exists!');
                        window.location.href = 'work/admin/addEmployee.php';</script>";
                }
                else {
                    // Hash the password using password_hash
                    $hashed_password = password_hash($employeePassword, PASSWORD_BCRYPT);
                    // Retrieve the department id
                    $dept = "SELECT dept_id FROM DEPARTMENT WHERE dept_name = '$dept_name'";
                    $dept_res = $conn->query($dept);

                    if ($dept_res->num_rows > 0) {
                        $row = $dept_res->fetch_assoc();
                        $dept_id = $row["dept_id"];

                        $ins = "INSERT INTO EMPLOYEE (emp_name, emp_email, emp_phone, emp_gender, emp_pass, dept_id) VALUES ('$employee_name', '$employee_email', '$employee_phone', '$employee_gender', '$hashed_password', '$dept_id')";
                        if ($conn->query($ins) === TRUE) {
                            echo "<script>alert('Employee Added Successfully');
                            window.location.href='../admin/adminEmployee.php'</script>";
                        } 
                        else {
                            echo "<script>alert('Error While Inserting.');
                            window.location.href='../admin/addEmployee.php'</script>";
                        }
                    } 
                                                  
                }
            }
            else {
                echo "<script>alert('Fill out all details');
                window.location.href='../admin/addEmployee.php'</script>";
            } 
        }

        // ------- Edit Employee --------
        if (isset($_POST['editEmployee'])) {

            $employee_name = $_POST['emp_name'];
            $employee_email  = $_POST['emp_email'];
            $employee_phone = $_POST['emp_phone'];
            $employee_gender = $_POST['emp_gender'];
            $dept_name = $_POST['dept_name'];
            $old_emp_email = $_POST['old_emp_email'];

            if ( isset($employee_name, $employee_email, $employee_phone, $employee_gender, $dept_name, $old_emp_email) ) {

                $dept = "SELECT dept_id FROM DEPARTMENT WHERE dept_name= '$dept_name'";
                $dept_res = $conn->query($dept);

                if ($dept_res->num_rows > 0) {
                    $row = $dept_res->fetch_assoc();
                    $dept_id = $row["dept_id"];

                    $emp_update = "UPDATE EMPLOYEE SET emp_name = '$employee_name', emp_phone = '$employee_phone', emp_gender = '$employee_gender' , emp_email = '$employee_email', dept_id = $dept_id WHERE emp_email = '$old_emp_email'";
                    $update_res = $conn->query($emp_update);
    
                    if($update_res) {
                        echo "<script>alert('Employee Updated Successfully');
                        window.location.href='../admin/adminEmployee.php'</script>";
                    } 
                    else {
                        echo "<script>alert('Error while Updating.');
                        window.location.href='../admin/adminEmployee.php'</script>";
                    }                        
                }               
            }
            else {
                echo "<script>alert('Fill out all details');
                window.location.href='../admin/adminEmployee.php'</script>";
            } 
        }

        // ------- Add Task --------
 
if (isset($_POST['addTask'])) {
    // Enable mysqli error reporting
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    ini_set('log_errors', 1);
    ini_set('error_log', 'error.log');
error_reporting(E_ALL);
ini_set('display_errors', 1);

    // Extract POST data
    $employee_name = $_POST['emp_name'];
    $task_name = $_POST['task_name'];
    $task_desc = $_POST['task_desc'];
    $task_type = $_POST['task_type'];
    $end_date = $_POST['end_date'];
	
	if(isset($_POST['assistant_name'])) {
    $assistant_name = $_POST['assistant_name'];
} elseif(isset($_POST['topo_assistant_name'])) {
    $assistant_name = $_POST['topo_assistant_name'];
} else {
    // Handle the case where neither assistant_name nor topo_assistant_name is posted
    $assistant_name = ""; // Set a default value or perform any other action
}

    // Adding 24 hours (86400 seconds) to the end_date
    $new_end_date = date('Y-m-d H:i:s', strtotime($end_date) + 24 * 60 * 60);

    // $new_end_date now contains the original end_date plus 24 hours


    if (isset($employee_name, $task_name, $task_type)) {
        // Get employee ID
        $emp_query = "SELECT emp_id FROM EMPLOYEE WHERE emp_name = ?";
        $stmt_emp = $conn->prepare($emp_query);
        $stmt_emp->bind_param("s", $employee_name);
        $stmt_emp->execute();
        $result_emp = $stmt_emp->get_result();
        $emp_row = $result_emp->fetch_assoc();
        $emp_id = $emp_row['emp_id'];
        $stmt_emp->close();
		
		$current_date = date("Ymd");

		// Generate a random number between 1000 and 9999
		$random_number = mt_rand(1000, 9999);

		// Concatenate strings and variables to create the task ID using the "." operator
		$taskID = $emp_id . "_" . $current_date . "_" . $random_number;
		
		//echo $taskID;
        
		// Insert task details
		$ins_task_query = "INSERT INTO TASK (task_id, task_title, task_desc, task, assistant_name, startDate, endDate) VALUES (?,?, ?, ?, ?, ?, ?)";
        
		$stmt_task = $conn->prepare($ins_task_query);

        if ($stmt_task === false) {
            echo "Error in prepare statement: " . $conn->error;
        } else {
            $stmt_task->bind_param("sssssss", $taskID,$task_name, $task_desc, $task_type, $assistant_name,$end_date,$new_end_date);

            if ($stmt_task->execute()) {
				
                //$last_inserted_task_id = $conn->insert_id;
                
                $prog="In Progress";
                // Insert task status
                $insert_task_status_query = "INSERT INTO TASK_STATUS (task_id, emp_id,task_status) VALUES (?, ?, ?)";
                $stmt_task_status = $conn->prepare($insert_task_status_query);

                if ($stmt_task_status) {
                    $stmt_task_status->bind_param("sis", $taskID, $emp_id,$prog);
                    $stmt_task_status->execute();
                } else {
                    echo "<script>alert('Task Added...'); window.location.href='createTask.php';</script>";
                }
				
		if($task_type=="Topo"){

			if (isset($_FILES['topo_photo_upload'])) {
					
					
                    $file = $_FILES['topo_photo_upload'];
                    $taskId = $taskID;
					//print_r($_FILES);

                    // Check if the file was uploaded without errors
                    if ($file['error'] == UPLOAD_ERR_OK) 
					{
                        // Create a folder with the name of the task ID
                        $folderPath = "../uploads/$taskId/";

                        if (!file_exists($folderPath)) {
                            mkdir($folderPath, 0777, true);
                        }
                        
                        // Get the current date
                        //$currentDate = date("Ymd_His");
						$originalFileName = $file['name'];
						$fileExtension = pathinfo($originalFileName, PATHINFO_EXTENSION);
						$newFileName = $task_name .'.' . $fileExtension;

					//$photoPath = $folderPath . $newFileName;

					$tmpFilePath = $file['tmp_name'];

					if ($tmpFilePath != "") {
						// Setup our new file path
						$newFilePath = $folderPath . $newFileName;

					// Upload the file into the temp dir
					if (move_uploaded_file($tmpFilePath, $newFilePath)) 
					{
						// Update the task record with the file path
						// $update_task_photo_query = "UPDATE TASK SET photo_file = ? WHERE task_id = ?";
						// $stmt_update_task_photo = $conn->prepare($update_task_photo_query);
						// $stmt_update_task_photo->bind_param("si", $photoPath, $last_inserted_task_id);
						// $stmt_update_task_photo->execute();
						// $stmt_update_task_photo->close();
									

                            echo "<script>alert('Task Added Successfully'); window.location.href='createTask.php';</script>";

                            
                        } else {
                            echo "<script>alert('Error uploading the file.'); window.location.href='createTask.php';</script>";
                        }
                    } else {
						echo "File Upload Error Code: " . $file['error'];
                        echo "<script>alert('Error uploading file.'); window.location.href='createTask.php';</script>";
                    }
                } else {
                     echo "<script>alert('No File Uploaded'); window.location.href='createTask.php';</script>";
                }
                
                
								//	$tmpFilePath = $_FILES['upload']['tmp_name'][$i];
                                        
                                    //Make sure we have a file path
                                //    if ($tmpFilePath != ""){
                                        //Setup our new file path
                                 //       $newFilePath = "../uploads/$taskId/" . uniqid() . '_' . basename($_FILES['upload']['name'][$i]);
                                        
                                        //Upload the file into the temp dir
                                //        if(move_uploaded_file($tmpFilePath, $newFilePath)) 
                                            {
                                            //   echo "<script>alert('Okay')";
                                        
                                            }
                    }
}
if($task_type=="Marking"){

                // Photo upload
                if (isset($_FILES['photo_upload'])) {
					
					
                    $file = $_FILES['photo_upload'];
                    $taskId = $taskID;
					//print_r($_FILES);

                    // Check if the file was uploaded without errors
                    if ($file['error'] == UPLOAD_ERR_OK) 
					{
                        // Create a folder with the name of the task ID
                        $folderPath = "../uploads/$taskId/";

                        if (!file_exists($folderPath)) {
                            mkdir($folderPath, 0777, true);
                        }

                            
                        
                        // Get the current date
                        //$currentDate = date("Ymd_His");
						$originalFileName = $file['name'];
						$fileExtension = pathinfo($originalFileName, PATHINFO_EXTENSION);
						$newFileName = $task_name .'.' . $fileExtension;

					//$photoPath = $folderPath . $newFileName;

					$tmpFilePath = $file['tmp_name'];

					if ($tmpFilePath != "") {
						// Setup our new file path
						$newFilePath = $folderPath . $newFileName;

					// Upload the file into the temp dir
					if (move_uploaded_file($tmpFilePath, $newFilePath)) 
					{
						// Update the task record with the file path
						// $update_task_photo_query = "UPDATE TASK SET photo_file = ? WHERE task_id = ?";
						// $stmt_update_task_photo = $conn->prepare($update_task_photo_query);
						// $stmt_update_task_photo->bind_param("si", $photoPath, $last_inserted_task_id);
						// $stmt_update_task_photo->execute();
						// $stmt_update_task_photo->close();
									

                            echo "<script>alert('Task Added Successfully'); window.location.href='createTask.php';</script>";

                            
                        } else {
                            echo "<script>alert('Error uploading the file.'); window.location.href='createTask.php';</script>";
                        }
                    } else {
						echo "File Upload Error Code: " . $file['error'];
                        echo "<script>alert('Error uploading file.'); window.location.href='createTask.php';</script>";
                    }
                } else {
                    echo "No file uploaded.".$file['name'];
                }
                
                
								//	$tmpFilePath = $_FILES['upload']['tmp_name'][$i];
                                        
                                    //Make sure we have a file path
                                //    if ($tmpFilePath != ""){
                                        //Setup our new file path
                                 //       $newFilePath = "../uploads/$taskId/" . uniqid() . '_' . basename($_FILES['upload']['name'][$i]);
                                        
                                        //Upload the file into the temp dir
                                //        if(move_uploaded_file($tmpFilePath, $newFilePath)) 
                                            {
                                            //   echo "<script>alert('Okay')";
                                        
                                            }
                    }
				
				
				
				
                //Files Upload
                    if (isset($_FILES['upload'])) 
                         {
                               // File upload
                               $total = count($_FILES['upload']['name']);
                               //echo $total;
                               //$files = $_FILES['file_upload'];
                               
                              $taskId = $taskID;
                            
                               // Create a folder with the name of the task ID
                               $folderPath = "../uploads/$taskId/";
                            
                                if (!file_exists($folderPath)) 
                                {
                                    mkdir($folderPath, 0777, true);
                                }
                    
                                for( $i=0 ; $i < $total ; $i++ ) 
                                {
                                        
                                    //Get the temp file path
                                    $tmpFilePath = $_FILES['upload']['tmp_name'][$i];
                                        
                                    //Make sure we have a file path
                                    if ($tmpFilePath != ""){
                                        //Setup our new file path
                                        $newFilePath = "../uploads/$taskId/" . uniqid() . '_' . basename($_FILES['upload']['name'][$i]);
                                        
                                        //Upload the file into the temp dir
                                        if(move_uploaded_file($tmpFilePath, $newFilePath)) 
                                            {
                                            //   echo "<script>alert('Okay')";
                                        
                                            }
                                          }
                                    }
                                
                                
                            }
                }
				
			if($task_type=="Others")
			{
						
						echo "<script>alert('Task Added Successfully'); window.location.href='createTask.php';</script>";
			
			} 
			
       }		else 
			{
                echo "<script>alert('Error While Inserting.'); window.location.href='createTask.php';</script>";
            }

            $stmt_task->close();
        }
    } else {
        echo "<script>alert('Fill out all details'); window.location.href='createTask.php';</script>";
    }
}






        
        // ------- Update Task --------
        if (isset($_POST['updateTask'])) 
        {
            
            // date_default_timezone_set('UTC');

            // // Get the current UTC time
            // $currentUtcTime = new DateTime();
            
            // // Convert UTC to IST
            // $currentIstTime = $currentUtcTime->setTimezone(new DateTimeZone('Asia/Kolkata'));
        
            $currentIstTime = date("Ymd_His");
            
            $updated_info = $_POST['updated_info'];
            $updated_date = $_POST['updated_date'];
            // $percentage = $_POST['percentage'];
            $task_status = $_POST['task_status'];
            $task_id = $_POST['task_id'];



            if ( isset($updated_info, $updated_date, $task_status) ) 
            {
                
                
                
                        // if (isset($_FILES['upload'])) 
                        // {
                               // File upload
                               $total = count($_FILES['upload']['name']);
                               //echo $total;
                               //$files = $_FILES['file_upload'];
                               $taskId = $task_id;
                            
                               // Create a folder with the name of the task ID
                               $folderPath = "../uploads/$taskId/";
                            
                                if (!file_exists($folderPath)) 
                                {
                                    mkdir($folderPath, 0777, true);
                                }
                    
                                for( $i=0 ; $i < $total ; $i++ ) 
                                {
                                        
                                    //Get the temp file path
                                    $tmpFilePath = $_FILES['upload']['tmp_name'][$i];
                                        
                                    //Make sure we have a file path
                                    if ($tmpFilePath != ""){
                                        //Setup our new file path
                                        $newFilePath = "../uploads/$taskId/" . uniqid() . '_' . basename($_FILES['upload']['name'][$i]);
                                        
                                        //Upload the file into the temp dir
                                        if(move_uploaded_file($tmpFilePath, $newFilePath)) 
                                            {
                                            //   echo "<script>alert('Okay')";
                                        
                                            }
                                          }
                                    }
                                
                                
            //}
                                

                //$update_sql = "UPDATE TASK_STATUS SET task_status = '$task_status', updated_info = '$updated_info', updated_date = '$updated_date' WHERE task_id = '$task_id'";
                //$update_task_sql = "UPDATE TASK SET endDate = CURRENT_TIMESTAMP WHERE task_id = '$task_id'";
				
                $update_sql = "UPDATE TASK_STATUS SET task_status = '$task_status', updated_info = '$updated_info', updated_date = '$updated_date' WHERE task_id = '$task_id'";
                
				//echo $updated_date;
				//$updatedTime = date('Y-m-d H:i:s', strtotime($updated_date)); // Format the time value to match database timestamp format
				//$updatedTime = date('H:i:s', strtotime($updated_date)); // Format the time value
				//echo "************";
				//echo $updatedTime;
				
				
				
				//updated_date
                //$update_task_sql = "UPDATE TASK SET endDate = CONVERT_TZ(NOW(), '+00:00', '+05:30') WHERE task_id = '$task_id'";
                
  
                if ($conn->query($update_sql)) 
                {   
					
					try {
								if ($task_status == 'Completed') {
									// Format the timestamp to match database timestamp format
									$updatedTime = date('Y-m-d H:i:s', strtotime($updated_date));
									
									// Prepare and execute the SQL query
									$update_task_sql = "UPDATE TASK SET endDate = ? WHERE task_id = ?";
									$stmt = $conn->prepare($update_task_sql);
									$stmt->bind_param("ss", $updatedTime, $task_id);
									$stmt->execute();
									
									// Check if the update was successful
									if ($stmt->affected_rows > 0) {
										echo "Task end date updated successfully.";
									} else {
										echo "No rows were affected.";
									}

									$stmt->close();
								}
							} catch (Exception $e) {
								 echo "Error: " . $e->getMessage();
							}
							  
					
                    echo "<script>alert('Task Updated Successfully');
                    window.location.href='../employee/employeeTaskStatus.php'</script>";
                } 
                else {
                    echo "<script>alert('Error While Updating.');
                    window.location.href='../employee/viewTasks.php'</script>";
                } 
        }
            else {
                echo "<script>alert('Fill out all details');
                window.location.href='../employee/viewTasks.php'</script>";
            } 
        
        }







        // -------- Edit Password --------
        if (isset($_POST['editPassword'])) {

            $old_password = $_POST['old_password'];
            $new_password = $_POST['new_password'];
            $emp_id = $_POST["emp_id"];

            if ( isset($old_password, $new_password, $emp_id) ) {
                
                $sql = "SELECT emp_pass FROM EMPLOYEE WHERE emp_id = $emp_id";
                $result = $conn->query($sql);
        
                if ($result->num_rows >= 0) {
                    $row = $result->fetch_assoc();
                    $old_pass = $row['emp_pass'];

                    if(password_verify($old_password,$old_pass)) {
                        $hashedPass = password_hash($new_password, PASSWORD_BCRYPT);

                        $update_sql = "UPDATE EMPLOYEE SET emp_pass = '$hashedPass' WHERE emp_id = $emp_id";
                        if ($conn->query($update_sql)) {
                            echo "<script>alert('Password Updated Successfully');
                            window.location.href='../employee/employeeDashboard.php'</script>";
                        } 
                        else {
                            echo "<script>alert('Error While Updating.');
                            window.location.href='../employee/editPassword.php'</script>";
                        }  
                    }
                    else {
                        echo "<script>alert('Password Mismatch');
                        window.location.href='../employee/editPassword.php'</script>";
                    } 
                }              
            }
            else {
                echo "<script>alert('Fill out all details');
                window.location.href='../employee/editPassword.php'</script>";
            } 
        }

    }   

?>