<?php 

    echo '<div class="topbar">
          <!--   <div class="toggle">
                <i class="fa-solid fa-bars"></i>
            </div> -->
            
            
            <div class="toggle" id="menuToggle">
<i class="fa-solid fa-bars"></i>
<div class="mobile-nav" id="mobileNav">
    <ul>
        <li><a href="adminDashboard.php">Dashboard</a></li>
        <li><a href="adminDepartment.php">Department</a></li>
        <li><a href="adminEmployee.php">Employees</a></li>
        <!--<li><a href="adminTaskStatus.php">Task Status</a></li> -->
        <!--<li><a href="viewFiles.php">View Files</a></li> -->
        <li><a href="adminTaskReport.php">Task Report</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
    <div class="close-icon" id="closeIcon">&#10006;</div>
</div>
</div>
            
            <!-- <div class="search">
                <label>
                    <input type="search" placeholder=" Search here... ">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </label>    
            </div> -->
            
            <!-- admin img -->
            <div class="profile">
                <div class="admin">
                    <img src="../images/'.$gender.'.png" alt="Admin">
                </div>
                <div class="admin_name">
                    <span>'.$name.'</span>
                </div>
            </div>
        </div>';
?>