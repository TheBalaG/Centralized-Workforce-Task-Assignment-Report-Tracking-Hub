<!DOCTYPE html>
<html lang="en">

<head>
  <?php
    $pageTitle = "CWTRH"; // Set the title for this page
    $cssFileName = "css/index.css";
    include "head.php"; // Include the common head section
   // date_default_timezone_set("Asia/Chennai");
  ?>
  
</head>

<body>

  <!-- **** Header Section **** -->
  <header id="header">
  
    <!-- Nav Bar-->
    <nav class="navbar" id="navbar">
     <div class="logo"><a href="index.php"><img src="images/logo.png" alt="logo"></a> <span class="menu-icon" 
      id="menuIcon"><i class="fa-solid fa-bars" style ="font-size:20px"></i></span></div>     
		
      <ul class="nav-links" id="navLinks">
        <li><a class="nav-link scrollto" href="adminLogin.php">Admin</a></li>
        <li><a class="nav-link scrollto" href="employeeLogin.php">Employee</a></li>
        <li><a class="nav-link scrollto" href="">Home</a></li>
      </ul>
    </nav>
	
  </header><!-- End Header -->

  <!-- **** Hero section **** -->
  <section id="hero">
    <div class="headings">
      <div class="main-heading">
       <p style="font-size: 35px;"> <br><b>Centralized Workforce Task Assignment and Report Tracking Hub</b></p>
  </div>
      <div class="login">
        <button><a href="employeeLogin.php"><b>Employee</b></a></button>
        <button><a href="adminLogin.php#about"><b>Admin</b></a></button>
       
      </div>

    </div>
    <img src="images/background.png" alt="Image">
  </section><!-- End Hero -->


  <!-- **** Footer **** -->
  <footer id="footer">
    <div class="content">
      <div class="top">
       
    </div>
    
    <div class="bottom-details">
      <div class="bottom_text">
        <span class="copyright_text">Copyright © 2024 <a href="#"></a>All rights reserved</span>
        <span class="policy_terms">
          <a href="#">Privacy policy</a>
          <a href="#">Terms & condition</a>
        </span>
		<!--
        <div class="logo-details">
		
          <!--<img src="images/logo.png" alt="logo" width="300" height="100" margin="10px">-->
        <!--   <img src="images/logo.png" alt="logo" height="100px">
        </div>
      </div>
    </div>
  </footer>
  
  -->
  
  <!-- Template Main JS File -->
  <script src="js/index.js"></script>  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</body>

</html>