// let toggle = document.querySelector('.toggle');
// let navigation = document.querySelector('.navigation');
// let main = document.querySelector('.main');

// // Function to add 'active' class when clicked on toggle
// toggle.addEventListener('click', function() {
//     navigation.classList.toggle('active');
//     main.classList.toggle('active');
// });

// document.addEventListener('DOMContentLoaded', function () {
//     var toggleButton = document.getElementById('menuToggle');
//     var mobileNav = document.getElementById('mobileNav');

//     toggleButton.addEventListener('click', function () {
//         // Toggle the visibility of the mobile nav
//         mobileNav.style.display = (mobileNav.style.display === 'none' || mobileNav.style.display === '') ? 'block' : 'none';
//     });

//     // Close the mobile nav when clicking outside of it
//     document.addEventListener('click', function (event) {
//         if (!mobileNav.contains(event.target) && event.target !== toggleButton) {
//             mobileNav.style.display = 'none';
//         }
//     });
// });

// document.addEventListener('DOMContentLoaded', function () {
//     var toggleButton = document.getElementById('menuToggle');
//     var mobileNav = document.getElementById('mobileNav');

//     toggleButton.addEventListener('click', function (event) {
//         // Prevent the click event from propagating to the document
//         event.stopPropagation();

//         // Toggle the visibility of the mobile nav
//         mobileNav.style.display = (mobileNav.style.display === 'none' || mobileNav.style.display === '') ? 'block' : 'none';
//     });

//     // Close the mobile nav when clicking outside of it
//     document.addEventListener('click', function (event) {
//         if (!mobileNav.contains(event.target) && event.target !== toggleButton) {
//             mobileNav.style.display = 'none';
//         }
//     });
// });

document.addEventListener('DOMContentLoaded', function () {
    var toggleButton = document.getElementById('menuToggle');
    var mobileNav = document.getElementById('mobileNav');
    var closeIcon = document.getElementById('closeIcon');

    toggleButton.addEventListener('click', function (event) {
        event.stopPropagation();
        // Toggle the visibility of the mobile nav
        mobileNav.style.display = (mobileNav.style.display === 'none' || mobileNav.style.display === '') ? 'block' : 'none';
    });

    closeIcon.addEventListener('click', function (event) {
        // Close the mobile nav when clicking the close icon
        mobileNav.style.display = 'none';
        event.stopPropagation();
    });

    // Close the mobile nav when clicking outside of it
    document.addEventListener('click', function (event) {
        if (!mobileNav.contains(event.target) && event.target !== toggleButton) {
            mobileNav.style.display = 'none';
        }
    });
});



// document.addEventListener('DOMContentLoaded', function() {
//     let toggle = document.querySelector('.toggle');
//     let navigation = document.querySelector('.navigation');
//     let main = document.querySelector('.main');

//     // Function to toggle 'active' class when clicked on toggle
//     toggle.addEventListener('click', function() {
//         // Toggle the 'active' class on both navigation and main
//         navigation.classList.toggle('active');
//         main.classList.toggle('active');

//         // Set a session variable to remember the state
//         let isActive = navigation.classList.contains('active');
//         sessionStorage.setItem('navigationActive', isActive);
//     });

//     // Check the session variable on page load and hide the navigation bar by default
//     let isActive = sessionStorage.getItem('navigationActive');
//     if (isActive === 'true') {
//         navigation.classList.add('active');
//         main.classList.add('active');
//     } else {
//         navigation.classList.remove('active');
//         main.classList.remove('active');
//     }

//     // Listen for page unload or beforeunload to close the sidebar
//     window.addEventListener('beforeunload', function() {
//         sessionStorage.setItem('navigationActive', 'false');
//     });
// });
