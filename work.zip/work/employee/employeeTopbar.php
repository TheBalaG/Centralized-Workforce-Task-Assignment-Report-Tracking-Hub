<?php 

    echo '<div class="topbar">
            
    <!-- <div class="toggle">
                <i class="fa-solid fa-bars"></i>
            </div>
-->

<div class="toggle" id="menuToggle">
<i class="fa-solid fa-bars"></i>
<div class="mobile-nav" id="mobileNav">
    <ul>
        <li><a href="createTask.php">Create Task</a></li>
        <li><a href="employeeTaskStatus.php">Task Status</a></li>
        <li><a href="editPassword.php">Edit Password</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
    <div class="close-icon" id="closeIcon">&#10006;</div>
</div>
</div>


            



            <!--<div class="search">
                 <label>
                    <input type="search" placeholder=" Search here... ">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </label>      
            </div>-->
            <!-- employee img -->
            <div class="profile">
                <div class="employee">
                    <img src="../images/'.$gender.'.png" alt="Employee">
                </div>
                <div class="employee_name">
                    <span>'.$name.'</span>
                </div>
            </div>
        </div>';
?>