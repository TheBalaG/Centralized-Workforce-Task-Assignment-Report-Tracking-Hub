<!DOCTYPE html>
<html lang="en">

<head>
    
    <?php
        $pageTitle = "Task"; // Set the custom title for this page
        $cssFileName = "../css/admin.css";
        include "../head.php"; // Include the common head section
    ?> 
    <link rel="stylesheet" href="../css/sidebar.css">
    <link rel="stylesheet" href="../css/topbar.css">
    
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script type="text/javascript">
        function getDepartmentName(val) 
		{
            $.ajax({
                type : "POST",
                url : "getDepartment.php",
                data : {dept_name : val},
                success : function(data){
                    $('#emp_name').html(data);
                }
            });
        }


   function toggleFields() 
   {
    var taskType = document.getElementById('task_type').value;
    var topoFields = document.getElementById('topoFields');
    var markingFields = document.getElementById('markingFields');
    var otherFields = document.getElementById('otherFields');

    // Hide all fields
    topoFields.style.display = 'none';
    markingFields.style.display = 'none';
    otherFields.style.display = 'none';

    console.log('Selected Task Type:', taskType);

    // Show fields based on the selected task priority
    if (taskType === 'Topo') {
        topoFields.style.display = 'block';
        console.log('Displaying Topo Fields');
    } else if (taskType === 'Marking') {
        markingFields.style.display = 'block';
        console.log('Displaying Marking Fields');
    } else if (taskType === 'other') {
        otherFields.style.display = 'block';
        console.log('Displaying Other Fields');
    }
}



    </script>

</head>
<body>
    
    <?php 
        session_start();
        
        
        include '../php/config.php';
        
        error_reporting(E_ALL);
        ini_set('display_errors', 1);
            

        $emp_id = $_SESSION['employee_id'];

        $emp = "SELECT emp_name, emp_gender FROM EMPLOYEE WHERE emp_id = $emp_id";
        $emp_result = $conn->query($emp);
        
        if ($emp_result->num_rows > 0) 
        {
            $emp_row = $emp_result->fetch_assoc();
            $name = $emp_row["emp_name"];
            $gender = $emp_row["emp_gender"];
        }
        
            $checkTasks = "SELECT COUNT(*) as task_count FROM TASK_STATUS WHERE emp_id = $emp_id AND task_status != 'Completed'";
            $taskResult = $conn->query($checkTasks);
            $taskCount = $taskResult->fetch_assoc()['task_count'];
            echo $taskCount;

    if ($taskCount > 0) 
    {
        echo "<div> <h2 style='color: red;'>Already task Assigned. </h2> </div>";
    }
        // $dept = "SELECT dept_name FROM DEPARTMENT WHERE admin_id = $admin_id";
        // $result_dept = $conn->query($dept);

        // $department_names = array();

        // if ($result_dept->num_rows > 0) {
        //     while ($row = $result_dept->fetch_assoc()) {
        //         $department_names[] = $row["dept_name"];
        //     }
        // }


        ?>

    <div class="container">
        <!-- **** Navigation Bar **** -->
        <?php include 'employeeSidebar.php' ?>
   
        <!-- Main Content-->
        <div class="main">

            <!--- ***** Topbar ****** -->
            <?php include 'employeeTopbar.php' ?>

            <!--- ***** Add task ****** -->
            <section id="task">

                <!--- ***** Box ****** -->
                <div class="box">
                    <div class="title">
                        <p>Add Task</p>
                    </div>
                    
                    
                     <?php
                     

                                 if ($taskCount > 0) 
                                {
                                    echo "<div> <h2 style='color: red;'>Already task Assigned. </h2> </div>";
                                }   
                      
                     ?>
                   <!-- <form action="process.php" method="post"  enctype="multipart/form-data" >  -->
					<form id="addTaskForm" action="process.php" method="post" enctype="multipart/form-data">

                        <!-- <p>
                            <label for="dept_name">Department Name :</label>
                            <select name="dept_name" id="dept_name" onchange="getDepartmentName(this.value);" required>
                                <option value="" disabled selected>---- Select Department ----</option>
                                <?php 
                                 //   foreach ($department_names as $dept_name) {
                                 //       echo "<option value='$dept_name'>$dept_name</option>";
                                  //  }
                                ?>
                            </select>
                        </p> -->

                        <p>
    <label for="emp_name">Employee Name:</label>
    <input type="text" name="emp_name" id="emp_name" value="<?php echo $name; ?>" readonly>
</p>


                        <p>
                            <label for="task_name">Site Name :</label>
                            <input type="text" name="task_name" id="task_name" required/>
                        </p>

                        <p>
                            <label for="task_desc">Location</label>
                            <input type="text" name="task_desc" id="task_desc" required/>
                        </p>

                        <!-- <p>
                            <label for="task_priority">Task Priority :</label>
                            <select name="task_priority" id="task_priority" required>
                                <option value="">---- Select Task Priority ----</option>
                                <option value="Normal">Normal</option>
                                <option value="Medium">Medium</option>
                                <option value="Urgent">Urgent</option>
                                <option value="Most Urgent">Most Urgent</option>
                            </select>
                        </p> -->

                         <p>
                            <label for="end_date">Start date :</label>
                            <input type="datetime-local" name="end_date" id="end_date" readonly required/>
                        </p>

                        <p>
    <label for="task_type">Type of Work *</label>
    <select name="task_type" id="task_type" required onchange="toggleFields()">
        <option value="">---- Select Type of Work ----</option>
        <option value="Topo">Topo</option>
        <option value="Marking">Marking</option>
        <option value="Others">Other</option>
    </select>
</p>

<div id="topoFields" style="display: none;">
    <p>
        <label for="topo_assistant_name">Assistant Name:</label>
        <input type="text" name="topo_assistant_name" id="assistant_name">
    </p>
	
    <p>
        <label for="topo_photo_upload">Photo Upload:</label>
        <input type="file" name="topo_photo_upload" id="photo_upload">
    </p>
</div>


<div id="markingFields" style="display: none;">
    <p>
        <label for="assistant_name">Assistant Name:</label>
        <input type="text" name="assistant_name" id="assistant_name">
    </p>
   <p>
        <label for="photo_upload">Photo Upload:</label>
        <input type="file" name="photo_upload" id="photo_upload">
    </p>
    <p>
        <label for="file_upload">File Upload:</label>
        <input type="file" name="upload[]" id="file_upload" multiple="multiple" >
    </p> 
</div>


<div id="otherFields" style="display: none;">
    <!-- Add any fields specific to "other" here -->
</div>


                        <?php 
                        
                        if ($taskCount > 0) 
                                {
                        
                                                        echo '<div class="submitBtn">
                                                                 <button type="submit" name="addTask" disabled>Add</button>
                                                              </div>';
                                }
                        else
                        {
                            echo ' <div class="submitBtn">
                            <button type="submit" name="addTask">Add</button>';
                        }
                        ?>

                        <!-- </div> -->

                    </form>
                </div>
            </section>            

        </div>

    </div>

    <script src="../js/adminDashboard.js" type="text/javascript"></script>
    <script>
        const currentDate = new Date();
currentDate.setTime(currentDate.getTime() + (5.5 * 60 * 60 * 1000)); 
let currentDateTime = currentDate.toISOString().slice(0, 16);
document.getElementById("end_date").value = currentDateTime;
    </script>

</body>

</html>